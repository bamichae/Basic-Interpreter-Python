def hw2(input, output):
    import sys

    l = []
    fileIn = open(input, 'r')   #file in
    fileOut = open(output, 'w') #fileout

    f = fileIn.read()
    pushFlag = False               #flag to see if push is read in


    for word in f.split():
        if word == '-0':       #edge case
                word = '0'
        elif pushFlag is True:       #if the flag is true, add the line to the stack, then change flag to false
            l.append(word)
            pushFlag = False
        elif word == 'push':         #if the word is push, change flag for next loop iteration
            pushFlag = True
        elif word == 'pop':
            if len(l) == 0:
                l.append(':error:')
            else:
                l.pop()
        elif word == ':false':              #prints boolearn false
            l.append(':false:')
        elif word == ':true:':               #prints boolean true
            l.append(':true:')
        elif len(l) == 0:                #if the list is empty, skip attempted operation
            l.append(':error:')
            continue
        elif word == ':error:':
            l.append(':error:')
        elif word == 'neg':              #if word is negative, negate value
            x = l[-1]
            if x == '0':
                continue
            elif x[0].isdigit():
                l[-1] = ('-' + l[-1])            #negate the last element of list if '-' is in word
            else:
                l[-1] = x[1:]
        elif word == 'add' or word == 'sub' or word == 'mul' or word == 'div' or word == 'rem':
            if len(l) < 2:
                l.append(':error:')
                continue
            x = l[-1]
            y = l[-2]
            if x[0].isdigit():
                pass
            elif x[0] == '-':
                pass
            else:
                l.append(':error:')
                continue
            if y[0].isdigit():
                pass
            elif y[0] == '-':
                pass
            else:
                l.append(':error:')
                continue
            if word == 'add':
                x = int(l[-2]) + int(l[-1])       #if word is add, convert to ints and add
                l.pop()
                l.pop()               #convert back to a string
                l.append(str(x))
            elif word == 'sub':
                x = int(l[-2]) - int(l[-1])    #if sub, covert to ints and sub
                l.pop()
                l.pop()
                l.append(str(x))
            elif word == 'mul':                   #multiplic
                x = int(l[-2]) * int(l[-1])
                l.pop()
                l.pop()
                x = int(x)
                l.append(str(x))
            elif word == 'div':                     #division
                if int(l[-1]) == 0:
                    l.append('error')
                    continue
                x = int(l[-2]) / int(l[-1])
                l.pop()
                l.pop()
                x = int(x)
                l.append(str(x))
            elif word == 'rem':                        #remainder
                if int(l[-2]) == 0:
                    l.append(':error:')
                    continue
                x = int(l[-2]) % int(l[-1])
                l.pop()
                l.pop()
                x = int(x)
                l.append(str(x))
        elif word == 'swap':                        #swap
            if len(l) < 2:
                l.append(':error:')
                continue
            x = l[-1]
            y = l[-2]
            l.pop()
            l.pop()
            l.append(x)
            l.append(y)

        elif word != 'quit':
            l.append(':error:')
            continue


    while len(l) > 0:              #print what is in the list from back to front
        if l[-1] == 'quit':
            sys.exit()
        print(l[-1])
        fileOut.write(l[-1] + '\n')
        l.pop()



    fileIn.close()
    fileOut.close()
